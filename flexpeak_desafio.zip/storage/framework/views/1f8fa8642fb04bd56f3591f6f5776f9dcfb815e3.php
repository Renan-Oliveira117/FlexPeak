<!doctype html>
<html lang="en">

<head>
<style>     
 body{

     background-color:cornflowerblue;
     
 }


</style>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="/css/app.css">
    

    <title><?php echo $__env->yieldContent('titulo'); ?></title>
</head>

<body>



    <div class="container">
        <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
        <?php echo $__env->yieldContent('conteudo'); ?>

        

    </div>


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="/js/app.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootbox.js/5.4.0/bootbox.min.js"></script>
    <?php echo $__env->yieldPushContent('js'); ?>
</body>

</html><?php /**PATH C:\laragon\www\flexpeak_desafio\resources\views/layout/master.blade.php ENDPATH**/ ?>