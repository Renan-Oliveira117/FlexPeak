<?php $__env->startSection('titulo','Contato'); ?>

<?php $__env->startSection('conteudo'); ?> 

<!-- Tela para listar todos os contatos salvos -->
<br>
<h1>LISTA DE CONTATO</h1>
<br>
<div class="col-lg-12" style="text-align: right;">
<a class="btn btn-primary " href="contatos/create">Cadastra Novo</a>
</div>
<br> 

<!--Titulo das colunas da tabelas -->
<table class="table table-bordered">
    <thead class="thead-dark">
        <tr>
            <th scope="col">ID</th>
            <th scope="col">NOME</th>
            <th scope="col">TELEFONE</th>
            <th scope="col">CPF</th>
            <th scope="col">RUA</th>
            <th scope="col">CIDADE</th>
            <th scope="col">AÇÕES</th>
        </tr>
    </thead>
   
        <!-- Retornar todos os contatos salvo-->
        <?php $__currentLoopData = $contatos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        

        <tr>
           
            <td><?php echo e($c->id); ?></td>
            <td><?php echo e($c->nome); ?></td>
            <td><?php echo e($c->telefone); ?></td>
            <td><?php echo e($c->cpf); ?></td>
            <td><?php echo e($c->rua); ?></td>
            <td><?php echo e($c->cidade); ?></td>
            <td>

                <a class="btn btn-warning" href="/contatos/edit/<?php echo e($c->id); ?>"> Editar</a>
                <a class="btn btn-danger" href="javascript:excluirContato(<?php echo e($c->id); ?>)">Excluir</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>





<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
    // bootbox.alert("Mensagem de teste")
    function excluirContato(id) {
        bootbox.confirm("Deseja mesmo excluir esse contato?", function(sim) {

            if (sim) {
                // bootbox.alert("Deve excluir o cliente com ID:" + id);
                axios.delete('/contato/' + id)
                    .then(function(resposta) {
                        window.location.href = "/contatos";

                    })

                    .catch(function(erro) {
                        bootbox.alert("Ocoreu um erro:" + erro);
                    });

            }
        });
    }
</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\flexpeak_desafio\resources\views/contato/index.blade.php ENDPATH**/ ?>