<?php $__env->startSection('titulo','Cadastra Contato'); ?>

<?php $__env->startSection('conteudo'); ?>

<h1>Formulário de Contato</h1>


<form method='post'>
  <?php echo csrf_field(); ?>

  <?php if(isset($contato)): ?>
  <?php echo method_field('PUT'); ?>
  <?php endif; ?>
  <div class="container-fluid">
  <div class="form-group">
    <label for="exampleInputEmail1">Nome</label>
    <input type="text" class="form-control" name="nome" value="<?php echo e($contato->nome ?? null); ?>">
  </div>

  <div class="form-group">
    <label for="exampleInputEmail1">Telefone</label>
    <input type="text" class="form-control" name="telefone" value="<?php echo e($contato->telefone ?? null); ?>">
  </div>

  <div class="form-group">
    <label for="exampleInputEmail1">CPF</label>
    <input type="text" class="form-control" name="cpf" value="<?php echo e($contato->cpf ?? null); ?>">
  </div>

  <div class="form-group">
    <label for="exampleInputPassword1">Rua</label>
    <input type="text" class="form-control" name="rua" value="<?php echo e($contato->rua ?? null); ?>">
  </div>

  <div class="form-group">
    <label for="exampleInputPassword1">Cidade</label>
    <input type="text" class="form-control" name="cidade" value="<?php echo e($contato->cidade ?? null); ?>">
  </div>

  <button type="submit" class="btn btn-primary">Salvar</button>
  <a class="btn btn-warning" href="/contatos">Cancelar</a>

</div>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\flexpeak_desafio\resources\views/contato/form.blade.php ENDPATH**/ ?>